var searchData=
[
  ['float_5fcoeffx_0',['float_coeffx',['../bouton_8c.html#ad216a0a62c3a4c754f60705ce4944eb0',1,'float_coeffX:&#160;fenetre.c'],['../fenetre_8c.html#ad216a0a62c3a4c754f60705ce4944eb0',1,'float_coeffX:&#160;fenetre.c'],['../main_8c.html#ad216a0a62c3a4c754f60705ce4944eb0',1,'float_coeffX:&#160;fenetre.c']]],
  ['float_5fcoeffy_1',['float_coeffy',['../bouton_8c.html#a93e2b93f0c79a6a7f94f6b893250463d',1,'float_coeffY:&#160;fenetre.c'],['../fenetre_8c.html#a93e2b93f0c79a6a7f94f6b893250463d',1,'float_coeffY:&#160;fenetre.c'],['../main_8c.html#a93e2b93f0c79a6a7f94f6b893250463d',1,'float_coeffY:&#160;fenetre.c']]]
];
