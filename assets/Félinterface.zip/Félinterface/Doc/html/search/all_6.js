var searchData=
[
  ['global_5finit_0',['global_init',['../main_8c.html#ad779b8a2050a08ab5e34ba16623cfa10',1,'global_init():&#160;main.c'],['../main_8h.html#ad779b8a2050a08ab5e34ba16623cfa10',1,'global_init():&#160;main.c']]],
  ['global_5fquit_1',['global_quit',['../main_8c.html#ad1737b9523db052203ab8e65ac7e25ad',1,'global_quit(Bouton *tabBouton):&#160;main.c'],['../main_8h.html#ad1737b9523db052203ab8e65ac7e25ad',1,'global_quit(Bouton *tabBouton):&#160;main.c']]]
];
