var searchData=
[
  ['puissance_0',['puissance',['../entier_8c.html#a255720885e788ab15648ba3cad1cb6ce',1,'puissance(int n, int x):&#160;entier.c'],['../entier_8h.html#a255720885e788ab15648ba3cad1cb6ce',1,'puissance(int n, int x):&#160;entier.c']]]
];
