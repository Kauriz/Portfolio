#Félinterface
Application pour apprendre SDL et s'améliorer en manipulation de fichier texte.

## Description
Un programme c qui affiche une fenêtre avec 2 boutons, l'un pour créer des boutons, l'autre pour en supprimer. Chaque bouton créer affiche 1 dans le terminal.

## Installation
Aucune installation n'est nécéssaire

## Utilisation
Ouvrer un terminal dans le dossier ou se trouve ce fichier puis éxecuter ./main pour lancer l'application

## Fichiers
Vous pouvez retrouver la documentation du projet dans le fichier Doc
Le Fichier F ne doit PAS ÊTRE SUPPRIMER, il contient le fichier de sauvegarde des boutons. 
Le fichier obj contient les fichier objets du projets

## Dépendances
gcc 13.3.0

## Contributeurs
Fait par LEBEL Axel
